import { useState, useMemo, useEffect } from 'react';

// ============================================================
// I18N - All UI text in English, Hindi, Marathi
// ============================================================
const I18N = {
  en: {
    appTitle: 'Prakruti Parikshan',
    appSubtitle: 'Ayurvedic Body Constitution Assessment',
    selectLanguage: 'Select Your Language',
    english: 'English',
    hindi: 'हिंदी',
    marathi: 'मराठी',
    start: 'Begin Assessment',
    next: 'Next',
    back: 'Back',
    notSure: 'Not sure / Neither',
    yes: 'Yes',
    no: 'No',
    question: 'Question',
    of: 'of',
    introTitle: 'About This Assessment',
    introText: 'This assessment is based on classical Ayurvedic features described in ancient texts. It helps you understand your predominant body constitution (Prakriti) — the balance of Vata, Pitta, and Kapha doshas that define your physical and mental tendencies.',
    disclaimer: 'This is an educational self-assessment based on classical Ayurvedic features. It is not a medical diagnosis. Consult a qualified Vaidya for proper Prakriti assessment.',
    optionalInfo: 'Basic Information (Optional)',
    name: 'Name',
    age: 'Age',
    gender: 'Gender',
    male: 'Male',
    female: 'Female',
    other: 'Other',
    skip: 'Skip',
    resultTitle: 'Your Prakriti Result',
    yourType: 'Your Prakriti Type',
    description: 'Description',
    dietTips: 'Diet & Lifestyle Guidance',
    download: 'Download / Print Result',
    retake: 'Retake Assessment',
    answerMore: 'Answer More Questions to Refine',
    continueAssessment: 'Continue Assessment',
    vata: 'Vata',
    pitta: 'Pitta',
    kapha: 'Kapha',
    percent: '%',
    langSwitch: 'Language',
    thanks: 'Thank you for completing this assessment!',
    printDate: 'Assessment Date',
  },
  hi: {
    appTitle: 'प्रकृति परीक्षण',
    appSubtitle: 'आयुर्वेदिक शरीर संरचना मूल्यांकन',
    selectLanguage: 'अपनी भाषा चुनें',
    english: 'English',
    hindi: 'हिंदी',
    marathi: 'मराठी',
    start: 'मूल्यांकन शुरू करें',
    next: 'आगे',
    back: 'पीछे',
    notSure: 'निश्चित नहीं / कोई नहीं',
    yes: 'हाँ',
    no: 'नहीं',
    question: 'प्रश्न',
    of: 'का',
    introTitle: 'इस मूल्यांकन के बारे में',
    introText: 'यह मूल्यांकन प्राचीन ग्रंथों में वर्णित शास्त्रीय आयुर्वेदिक लक्षणों पर आधारित है। यह आपको अपनी प्रमुख शरीर प्रकृति समझने में मदद करता है — वात, पित्त और कफ दोषों का संतुलन जो आपकी शारीरिक और मानसिक प्रवृत्तियों को परिभाषित करता है।',
    disclaimer: 'यह शास्त्रीय आयुर्वेदिक लक्षणों पर आधारित एक शैक्षिक स्व-मूल्यांकन है। यह चिकित्सा निदान नहीं है। उचित प्रकृति मूल्यांकन के लिए योग्य वैद्य से परामर्श करें।',
    optionalInfo: 'बुनियादी जानकारी (वैकल्पिक)',
    name: 'नाम',
    age: 'आयु',
    gender: 'लिंग',
    male: 'पुरुष',
    female: 'महिला',
    other: 'अन्य',
    skip: 'छोड़ें',
    resultTitle: 'आपकी प्रकृति परिणाम',
    yourType: 'आपकी प्रकृति',
    description: 'विवरण',
    dietTips: 'आहार और जीवनशैली मार्गदर्शन',
    download: 'परिणाम डाउनलोड / प्रिंट करें',
    retake: 'पुनः मूल्यांकन करें',
    answerMore: 'परिणाम बेहतर करने के लिए और प्रश्नों के उत्तर दें',
    continueAssessment: 'मूल्यांकन जारी रखें',
    langSwitch: 'भाषा',
    thanks: 'इस मूल्यांकन को पूरा करने के लिए धन्यवाद!',
    printDate: 'मूल्यांकन तिथि',
    vata: 'वात',
    pitta: 'पित्त',
    kapha: 'कफ',
  },
  mr: {
    appTitle: 'प्रकृती परीक्षण',
    appSubtitle: 'आयुर्वेदिक शरीर संरचना मूल्यांकन',
    selectLanguage: 'आपली भाषा निवडा',
    english: 'English',
    hindi: 'हिंदी',
    marathi: 'मराठी',
    start: 'मूल्यांकन सुरू करा',
    next: 'पुढे',
    back: 'मागे',
    notSure: 'नक्की नाही / कधी नाही',
    yes: 'होय',
    no: 'नाही',
    question: 'प्रश्न',
    of: 'पैकी',
    introTitle: 'या मूल्यांकनाबद्दल',
    introText: 'हे मूल्यांकन प्राचीन ग्रंथांत वर्णित केलेल्या शास्त्रीय आयुर्वेदिक लक्षणांवर आधारित आहे. हे तुम्हाला तुमची प्रमुख शरीर प्रकृती समजून घेण्यास मदत करते — वात, पित्त आणि कफ दोषांचा समतोल जो तुमच्या शारीरिक आणि मानसिक प्रवृत्ती ठरवतो.',
    disclaimer: 'हे शास्त्रीय आयुर्वेदिक लक्षणांवर आधारित एक शैक्षणिक स्व-मूल्यांकन आहे. हे वैद्यकीय निदान नाही. योग्य प्रकृती मूल्यांकनासाठी योग्य वैद्यांचा सल्ला घ्या.',
    optionalInfo: 'मूलभूत माहिती (ऐच्छिक)',
    name: 'नाव',
    age: 'वय',
    gender: 'लिंग',
    male: 'पुरुष',
    female: 'स्त्री',
    other: 'इतर',
    skip: 'वगळा',
    resultTitle: 'तुमचा प्रकृती निकाल',
    yourType: 'तुमची प्रकृती',
    description: 'वर्णन',
    dietTips: 'आहार आणि जीवनशैली मार्गदर्शन',
    download: 'निकाल डाउनलोड / प्रिंट करा',
    retake: 'पुन्हा मूल्यांकन करा',
    answerMore: 'निकाल सुधारण्यासाठी अधिक प्रश्नांची उत्तरे द्या',
    continueAssessment: 'मूल्यांकन चालू ठेवा',
    langSwitch: 'भाषा',
    thanks: 'हे मूल्यांकन पूर्ण केल्याबद्दल धन्यवाद!',
    printDate: 'मूल्यांकन तारीख',
    vata: 'वात',
    pitta: 'पित्त',
    kapha: 'कफ',
  }
};

// ============================================================
// QUESTION BANK - 50 questions in 3 languages
// Format: { id, tier, q:{en,hi,mr}, options: [{text:{en,hi,mr}, dosha:'V'|'P'|'K'|null}] }
// dosha null = "Not sure" option (auto-added)
// ============================================================
interface QuestionOption {
  text: { en: string; hi: string; mr: string };
  dosha: 'V' | 'P' | 'K' | null;
}

interface Question {
  id: number;
  tier: number;
  q: { en: string; hi: string; mr: string };
  options: QuestionOption[];
  binary?: boolean; // T3 yes/no questions
  skipIfNoDreams?: boolean; // conditional skip
}

const QUESTIONS: Question[] = [
  // TIER 1 - High value, 3-option
  { id: 1, tier: 1, q: { en: 'What best describes your body build (frame)?', hi: 'आपके शरीर का बनावट (ढाँचा) कैसा है?', mr: 'तुमच्या शरीराची बांधणी कशी आहे?' },
    options: [
      { text: { en: 'Thin, lean, hard to gain weight', hi: 'पतला, दुबला, वजन बढ़ाना मुश्किल', mr: 'सडपातळ, कृश, वजन वाढवणे कठीण' }, dosha: 'V' },
      { text: { en: 'Medium, moderate build', hi: 'मध्यम, संतुलित शरीर', mr: 'मध्यम, संतुलित शरीर' }, dosha: 'P' },
      { text: { en: 'Heavy / well built, gains weight easily', hi: 'भारी / गठीत, आसानी से वजन बढ़ता है', mr: 'जड / बांधेव, सहज वजन वाढते' }, dosha: 'K' },
    ]},
  { id: 2, tier: 1, q: { en: 'What is your skin texture like?', hi: 'आपकी त्वचा की बनावट कैसी है?', mr: 'तुमची त्वचा कशी आहे?' },
    options: [
      { text: { en: 'Dry, rough, cracks easily', hi: 'रूखी, खुरदरी, जल्दी दरारें', mr: 'कोरडी, खरखरीत, लवकर तडा जाते' }, dosha: 'V' },
      { text: { en: 'Moles, pimples, freckles; early wrinkles', hi: 'तिल, मुँहासे, झाइयाँ; जल्दी झुर्रियाँ', mr: 'तिळ, मुरुमे, वळ; लवकर सुरकुत्या' }, dosha: 'P' },
      { text: { en: 'Smooth, oily, clear skin', hi: 'मुलायम, तैलीय, साफ त्वचा', mr: 'मऊ, तेलकट, स्वच्छ त्वचा' }, dosha: 'K' },
    ]},
  { id: 3, tier: 1, q: { en: 'What is your natural skin colour?', hi: 'आपका प्राकृतिक रंग कैसा है?', mr: 'तुमचा नैसर्गिक रंग कसा आहे?' },
    options: [
      { text: { en: 'Dusky / dark complexion', hi: 'साँवला / गहरा रंग', mr: 'सावळा / गडद रंग' }, dosha: 'V' },
      { text: { en: 'Fair with yellowish tinge', hi: 'गोरा, पीलापन लिए', mr: 'गोरा, पिवळसर' }, dosha: 'P' },
      { text: { en: 'Fair, glowing (lotus/gold-like)', hi: 'गोरा, चमकदार (कमल/सोने जैसा)', mr: 'गोरा, तेजस्वी (कमळ/सोन्यासारखा)' }, dosha: 'K' },
    ]},
  { id: 4, tier: 1, q: { en: 'How does your body feel regarding warmth?', hi: 'आपके शरीर की गर्मी कैसी है?', mr: 'तुमच्या शरीराची उष्णता कशी आहे?' },
    options: [
      { text: { en: 'Feel hot easily, warm to touch, sensitive to heat/spicy food, mouth ulcers', hi: 'जल्दी गर्मी लगती है, स्पर्श से गर्म, गर्मी/मसालेदार से परेशानी, मुँह के छाले', mr: 'लवकर गरम वाटते, स्पर्शाने उष्ण, उष्णता/तिखट पदार्थांपासून त्रास, तोंडाच्या खरूज' }, dosha: 'P' },
      { text: { en: 'Body temperature on lower side, feel cool', hi: 'शरीर का तापमान कम, ठंडा महसूस', mr: 'शरीराचे तापमान कमी, थंड वाटते' }, dosha: 'K' },
    ]},
  { id: 5, tier: 1, q: { en: 'What is your hair like?', hi: 'आपके बाल कैसे हैं?', mr: 'तुमचे केस कसे आहेत?' },
    options: [
      { text: { en: 'Dry, rough, split ends, dusky', hi: 'रूखे, खुरदरे, दोमुँहे, साँवले', mr: 'कोरडे, खरखरीत, फाटलेले टोक, सावळे' }, dosha: 'V' },
      { text: { en: 'Soft, thin/scanty, reddish-brown', hi: 'मुलायम, पतले/कम, लाल-भूरे', mr: 'मऊ, बारीक/कमी, तांबूस-तपकिरी' }, dosha: 'P' },
      { text: { en: 'Thick, oily, dense, curly/black', hi: 'घने, तैलीय, मोटे, घुंघराले/काले', mr: 'जाड, तेलकट, दाट, घुंगुराळी/काळे' }, dosha: 'K' },
    ]},
  { id: 6, tier: 1, q: { en: 'How is your appetite (quantity of food)?', hi: 'आपकी भूख (खाने की मात्रा) कैसी है?', mr: 'तुमची भूक (अन्नाचे प्रमाण) कशी आहे?' },
    options: [
      { text: { en: 'Eat small amounts but frequently', hi: 'थोड़ा-थोड़ा लेकिन बार-बार खाते हैं', mr: 'थोडे-थोडे पण वारंवार खातो' }, dosha: 'V' },
      { text: { en: 'Frequent hunger, eat more', hi: 'जल्दी भूख लगती है, ज्यादा खाते हैं', mr: 'लवकर भूक लागते, जास्त खातो' }, dosha: 'P' },
      { text: { en: 'Less hunger, eat less', hi: 'कम भूख, कम खाते हैं', mr: 'कमी भूक, कमी खातो' }, dosha: 'K' },
    ]},
  { id: 7, tier: 1, q: { en: 'How well can you tolerate hunger?', hi: 'आप भूख कितनी सहन कर सकते हैं?', mr: 'तुम्ही भूक किती सहन करू शकता?' },
    options: [
      { text: { en: 'It varies / irregular', hi: 'कभी-कभी / अनियमित', mr: 'कधी-कधी / अनियमित' }, dosha: 'V' },
      { text: { en: 'Cannot tolerate skipping a meal', hi: 'खाना छोड़ना बर्दाश्त नहीं', mr: 'जेवण वगळणे सहन होत नाही' }, dosha: 'P' },
      { text: { en: 'Can easily tolerate hunger', hi: 'भूख आसानी से सहन कर लेते हैं', mr: 'भूक सहज सहन करता येते' }, dosha: 'K' },
    ]},
  { id: 8, tier: 1, q: { en: 'How fast do you eat?', hi: 'आप कितनी तेज़ी से खाते हैं?', mr: 'तुम्ही किती वेगाने खाता?' },
    options: [
      { text: { en: 'Fast eater, finish before others', hi: 'तेज़ खाते हैं, दूसरों से पहले खत्म', mr: 'वेगाने खातो, इतरांपूर्वी संपवतो' }, dosha: 'V' },
      { text: { en: 'Moderate speed', hi: 'सामान्य गति', mr: 'सामान्य गती' }, dosha: 'P' },
      { text: { en: 'Slow eater, finish after others', hi: 'धीरे खाते हैं, दूसरों के बाद खत्म', mr: 'हळू खातो, इतरांनंतर संपवतो' }, dosha: 'K' },
    ]},
  { id: 9, tier: 1, q: { en: 'How is your thirst and water intake?', hi: 'आपकी प्यास और पानी पीना कैसा है?', mr: 'तुमची तहान आणि पाणी पिणे कसे आहे?' },
    options: [
      { text: { en: 'Frequently thirsty, drink more water', hi: 'जल्दी प्यास लगती है, ज्यादा पानी पीते हैं', mr: 'लवकर तहान लागते, जास्त पाणी पितो' }, dosha: 'P' },
      { text: { en: 'Less thirst, drink less water', hi: 'कम प्यास, कम पानी पीते हैं', mr: 'कमी तहान, कमी पाणी पितो' }, dosha: 'K' },
    ]},
  { id: 10, tier: 1, q: { en: 'How much do you sweat?', hi: 'आपको कितना पसीना आता है?', mr: 'तुम्हाला किती घाम येतो?' },
    options: [
      { text: { en: 'Profuse sweating, strong body odour', hi: 'बहुत पसीना, तेज़ शरीर की गंध', mr: 'खूप घाम, तीव्र शरीराचा वास' }, dosha: 'P' },
      { text: { en: 'Scanty sweating, mild odour', hi: 'कम पसीना, हल्की गंध', mr: 'कमी घाम, सौम्य वास' }, dosha: 'K' },
    ]},
  { id: 11, tier: 1, q: { en: 'How is your sleep pattern?', hi: 'आपकी नींद कैसी है?', mr: 'तुमची झोप कशी आहे?' },
    options: [
      { text: { en: 'Light sleeper, wake easily, less than 6 hrs', hi: 'हल्की नींद, जल्दी जाग, 6 घंटे से कम', mr: 'हलकी झोप, लवकर जाग, 6 तासांपेक्षा कमी' }, dosha: 'V' },
      { text: { en: 'Moderate sleep, 6-8 hrs', hi: 'सामान्य नींद, 6-8 घंटे', mr: 'सामान्य झोप, 6-8 तास' }, dosha: 'P' },
      { text: { en: 'Love sleeping, sleep long, more than 8 hrs', hi: 'नींद पसंद, लंबी नींद, 8 घंटे से ज्यादा', mr: 'झोप आवडते, लांब झोप, 8 तासांपेक्षा जास्त' }, dosha: 'K' },
    ]},
  { id: 12, tier: 1, q: { en: 'How do you walk?', hi: 'आप कैसे चलते हैं?', mr: 'तुम्ही कसे चालता?' },
    options: [
      { text: { en: 'Quick, swift, small steps', hi: 'तेज़, फुर्तीले, छोटे कदम', mr: 'वेगाने, चपळ, लहान पाउले' }, dosha: 'V' },
      { text: { en: 'Moderate pace', hi: 'सामान्य चाल', mr: 'सामान्य गती' }, dosha: 'P' },
      { text: { en: 'Steady, straight, deliberate steps', hi: 'स्थिर, सीधे, सोचे-समझे कदम', mr: 'स्थिर, सरळ, विचारपूर्वक पाउले' }, dosha: 'K' },
    ]},
  { id: 13, tier: 1, q: { en: 'How do you start a new task?', hi: 'नया काम शुरू करते समय?', mr: 'नवीन काम सुरू करताना?' },
    options: [
      { text: { en: 'Start immediately, act fast', hi: 'तुरंत शुरू, तेज़ी से काम', mr: 'लगेच सुरू, वेगाने काम' }, dosha: 'V' },
      { text: { en: 'Moderate, balanced approach', hi: 'सामान्य, संतुलित', mr: 'सामान्य, संतुलित' }, dosha: 'P' },
      { text: { en: 'Delayed in starting, take time', hi: 'शुरू करने में देर, समय लेते हैं', mr: 'सुरू करण्यास उशीर, वेळ घेतो' }, dosha: 'K' },
    ]},
  { id: 14, tier: 1, q: { en: 'What is your general temperament?', hi: 'आपका सामान्य स्वभाव कैसा है?', mr: 'तुमचा सामान्य स्वभाव कसा आहे?' },
    options: [
      { text: { en: 'Fearful / anxious, changes mind often', hi: 'डरपोक / चिंतित, जल्दी मन बदलते है', mr: 'भीरू / चिंताग्रस्त, लवकर मन बदलते' }, dosha: 'V' },
      { text: { en: 'Gets angry quickly but calms quickly', hi: 'जल्दी गुस्सा, जल्दी शांत', mr: 'लवकर रागावतो, लवकर शांत होतो' }, dosha: 'P' },
      { text: { en: 'Calm, patient, rarely angry', hi: 'शांत, धैर्यवान, शायद ही गुस्सा', mr: 'शांत, संयमी, क्वचित रागावतो' }, dosha: 'K' },
    ]},
  { id: 15, tier: 1, q: { en: 'How are your friendships?', hi: 'आपकी दोस्ती कैसी है?', mr: 'तुमची मैत्री कशी आहे?' },
    options: [
      { text: { en: 'Few friends, fickle, make friends quickly', hi: 'कम दोस्त, अस्थिर, जल्दी दोस्ती', mr: 'कमी मित्र, अस्थिर, लवकर मैत्री' }, dosha: 'V' },
      { text: { en: 'Moderate, selective friendships', hi: 'सामान्य, चुनिंदा दोस्ती', mr: 'सामान्य, निवडक मैत्री' }, dosha: 'P' },
      { text: { en: 'Stable, long-lasting friendships', hi: 'स्थिर, लंबे समय तक चलने वाली दोस्ती', mr: 'स्थिर, दीर्घकाळ टिकणारी मैत्री' }, dosha: 'K' },
    ]},

  // TIER 2 - More detailed features
  { id: 16, tier: 2, q: { en: 'What is your height like?', hi: 'आपकी लंबाई कैसी है?', mr: 'तुमची उंची कशी आहे?' },
    options: [
      { text: { en: 'Tall (above ~6 ft / 183 cm)', hi: 'लंबा (~6 फुट से ऊपर)', mr: 'उंच (~6 फूटांपेक्षा जास्त)' }, dosha: 'V' },
      { text: { en: 'Medium height', hi: 'मध्यम लंबाई', mr: 'मध्यम उंची' }, dosha: 'P' },
      { text: { en: 'Short (below ~5 ft / 152 cm)', hi: 'छोटा (~5 फुट से नीचे)', mr: 'ठेंगणं (~5 फूटांपेक्षा कमी)' }, dosha: 'K' },
    ]},
  { id: 17, tier: 2, q: { en: 'What best describes your body frame features?', hi: 'आपके शरीर की बनावट कैसी दिखती है?', mr: 'तुमच्या शरीराची रचना कशी दिसते?' },
    options: [
      { text: { en: 'Prominent veins and tendons visible', hi: 'नसें और टेंडन स्पष्ट दिखते हैं', mr: 'नसा आणि स्नायू स्पष्ट दिसतात' }, dosha: 'V' },
      { text: { en: 'Delicate, fine body features', hi: 'नाज़ुक, सुंदर शरीर', mr: 'नाजूक, सुंदर शरीर' }, dosha: 'P' },
      { text: { en: 'Broad forehead, well-rounded features', hi: 'चौड़ा माथा, गोल-मटोल अंग', mr: 'रूंद कपाळ, गोल-माटोल अवयव' }, dosha: 'K' },
    ]},
  { id: 18, tier: 2, q: { en: 'Do your joints crack or make sounds during movement?', hi: 'क्या आपके जोड़ों में चलने पर आवाज़ आती है?', mr: 'चालताना तुमच्या सांध्यांतून आवाज येतो का?' },
    options: [
      { text: { en: 'Yes — joints crack, restless movement', hi: 'हाँ — जोड़ों में चरमराहट, बेचैन गति', mr: 'होय — सांधे चरमरातात, अस्थिर हालचाल' }, dosha: 'V' },
    ], binary: true },
  { id: 19, tier: 2, q: { en: 'How are your muscles?', hi: 'आपकी मांसपेशियाँ कैसी हैं?', mr: 'तुमचे स्नायू कसे आहेत?' },
    options: [
      { text: { en: 'Hard, prominent muscles', hi: 'कठोर, स्पष्ट मांसपेशियाँ', mr: 'कडक, स्पष्ट स्नायू' }, dosha: 'V' },
      { text: { en: 'Lax, soft muscles', hi: 'ढीली, मुलायम मांसपेशियाँ', mr: 'शिथिल, मऊ स्नायू' }, dosha: 'P' },
    ]},
  { id: 20, tier: 2, q: { en: 'What is your eye size like?', hi: 'आपकी आँखों का आकार कैसा है?', mr: 'तुमच्या डोळ्यांचा आकार कसा आहे?' },
    options: [
      { text: { en: 'Small eyes', hi: 'छोटी आँखें', mr: 'लहान डोळे' }, dosha: 'V' },
      { text: { en: 'Medium eyes', hi: 'मध्यम आँखें', mr: 'मध्यम डोळे' }, dosha: 'P' },
      { text: { en: 'Big, large eyes', hi: 'बड़ी, चौड़ी आँखें', mr: 'मोठे, रुंद डोळे' }, dosha: 'K' },
    ]},
  { id: 21, tier: 2, q: { en: 'What is the colour of your eye sclera (whites)?', hi: 'आपकी आँखों के सफेद भाग का रंग कैसा है?', mr: 'तुमच्या डोळ्यांच्या पांढऱ्या भागाचा रंग कसा आहे?' },
    options: [
      { text: { en: 'Dull white / greyish', hi: 'फीका सफेद / स्लेटी', mr: 'फिकट पांढरे / करडा' }, dosha: 'V' },
      { text: { en: 'Coppery / reddish tinge', hi: 'तांबिया / लालिमा', mr: 'तांबूस / लालसर' }, dosha: 'P' },
      { text: { en: 'Milky white, clear, bright', hi: 'दूधिया सफेद, साफ, चमकीला', mr: 'दुधासारखा पांढरा, स्वच्छ, तेजस्वी' }, dosha: 'K' },
    ]},
  { id: 22, tier: 2, q: { en: 'How are your eyelashes?', hi: 'आपकी पलकें कैसी हैं?', mr: 'तुमच्या पापण्या कशा आहेत?' },
    options: [
      { text: { en: 'Few / thin eyelashes', hi: 'कम / पतली पलकें', mr: 'कमी / बारीक पापण्या' }, dosha: 'P' },
      { text: { en: 'Thick, dense, long eyelashes', hi: 'घनी, मोटी, लंबी पलकें', mr: 'दाट, जाड, लांब पापण्या' }, dosha: 'K' },
    ]},
  { id: 23, tier: 2, q: { en: 'How do your eyes behave?', hi: 'आपकी आँखें कैसा व्यवहार करती हैं?', mr: 'तुमचे डोळे कसे वागतात?' },
    options: [
      { text: { en: 'Unsteady, frequent eye movements, dry eyes', hi: 'अस्थिर, बार-बार आँखें हिलती हैं, सूखी आँखें', mr: 'अस्थिर, वारंवार डोळे हलतात, कोरडे डोळे' }, dosha: 'V' },
      { text: { en: 'Eyes turn red with anger / sun / alcohol', hi: 'गुस्से / धूप / शराब से आँखें लाल', mr: 'राग / उन्ह / दारूने डोळे लाल' }, dosha: 'P' },
    ]},
  { id: 24, tier: 2, q: { en: 'What is your natural hair colour?', hi: 'आपके बालों का प्राकृतिक रंग?', mr: 'तुमच्या केसांचा नैसर्गिक रंग?' },
    options: [
      { text: { en: 'Dusky / brownish', hi: 'साँवला / भूरा', mr: 'सावळा / तपकिरी' }, dosha: 'V' },
      { text: { en: 'Reddish-brown / coppery', hi: 'लाल-भूरा / तांबिया', mr: 'तांबूस-तपकिरी' }, dosha: 'P' },
      { text: { en: 'Black / very dark', hi: 'काला / बहुत गहरा', mr: 'काळा / अतिगडद' }, dosha: 'K' },
    ]},
  { id: 25, tier: 2, q: { en: 'What are your nails like?', hi: 'आपके नाखून कैसे हैं?', mr: 'तुमचे नख कसे आहेत?' },
    options: [
      { text: { en: 'Small, thin, dry, fast-growing', hi: 'छोटे, पतले, रूखे, तेज़ी से बढ़ते', mr: 'लहान, बारीक, कोरडे, वेगाने वाढणारे' }, dosha: 'V' },
      { text: { en: 'Coppery / pinkish colour', hi: 'तांबिया / गुलाबी रंग', mr: 'तांबूस / गुलाबी रंग' }, dosha: 'P' },
      { text: { en: 'Long, thick, smooth', hi: 'लंबे, मोटे, मुलायम', mr: 'लांब, जाड, मऊ' }, dosha: 'K' },
    ]},
  { id: 26, tier: 2, q: { en: 'How is your voice?', hi: 'आपकी आवाज़ कैसी है?', mr: 'तुमचा आवाज कसा आहे?' },
    options: [
      { text: { en: 'Weak, hoarse, broken, fast speech', hi: 'कमज़ोर, बैठती, रुकी-रुकी, तेज़ बोलना', mr: 'अशक्त, बसलेला, खंडित, वेगाने बोलणे' }, dosha: 'V' },
      { text: { en: 'Sharp, loud, clear voice', hi: 'तीखी, ऊँची, स्पष्ट आवाज़', mr: 'तीक्ष्ण, मोठा, स्पष्ट आवाज' }, dosha: 'P' },
      { text: { en: 'Deep, clear, pleasant, melodious', hi: 'गहरी, स्पष्ट, मधुर, सुरीली', mr: 'खोल, स्पष्ट, गोड, सुरीत' }, dosha: 'K' },
    ]},
  { id: 27, tier: 2, q: { en: 'How is your comprehension / learning speed?', hi: 'आपकी समझ / सीखने की गति कैसी है?', mr: 'तुमची समज / शिकण्याची गती कशी आहे?' },
    options: [
      { text: { en: 'Grasp quickly but forget fast', hi: 'जल्दी समझते हैं, जल्दी भूलते हैं', mr: 'लवकर समजतो पण लवकर विसरतो' }, dosha: 'V' },
      { text: { en: 'Moderate comprehension', hi: 'सामान्य समझ', mr: 'सामान्य समज' }, dosha: 'P' },
      { text: { en: 'Grasp slowly but remember well', hi: 'धीरे समझते हैं, पर याद रहता है', mr: 'हळू समजतो पण चांगले लक्षात राहते' }, dosha: 'K' },
    ]},
  { id: 28, tier: 2, q: { en: 'How is your memory?', hi: 'आपकी याददाश्त कैसी है?', mr: 'तुमची स्मरणशक्ती कशी आहे?' },
    options: [
      { text: { en: 'Forget easily, unstable memory', hi: 'जल्दी भूल जाते हैं, अस्थिर याददाश्त', mr: 'लवकर विसरतो, अस्थिर स्मरणशक्ती' }, dosha: 'V' },
      { text: { en: 'Moderate memory', hi: 'सामान्य याददाश्त', mr: 'सामान्य स्मरणशक्ती' }, dosha: 'P' },
      { text: { en: 'Good long-term memory, steady', hi: 'अच्छी दीर्घकालिक याददाश्त, स्थिर', mr: 'चांगली दीर्घकालीन स्मरणशक्ती, स्थिर' }, dosha: 'K' },
    ]},
  { id: 29, tier: 2, q: { en: 'What kind of dreams do you often see?', hi: 'आप अक्सर कैसे सपने देखते हैं?', mr: 'तुम्ही सहसा कसे स्वप्न पाहता?' },
    options: [
      { text: { en: 'Flying, mountains, dry things, running', hi: 'उड़ना, पहाड़, सूखी चीज़ें, दौड़ना', mr: 'उडणे, डोंगर, कोरड्या गोष्टी, पळणे' }, dosha: 'V' },
      { text: { en: 'Fire, lightning, gold, bright colours', hi: 'आग, बिजली, सोना, चमकीले रंग', mr: 'आग, वीज, सोने, तेजस्वी रंग' }, dosha: 'P' },
      { text: { en: 'Water, lotus, swans, pleasant gardens', hi: 'पानी, कमल, हंस, सुंदर बगीचे', mr: 'पाणी, कमळ, हंस, सुंदर बाग' }, dosha: 'K' },
    ], skipIfNoDreams: true },
  { id: 30, tier: 2, q: { en: 'What do you generally prefer / like?', hi: 'आपको आमतौर पर क्या पसंद है?', mr: 'तुम्हाला सहसा काय आवडते?' },
    options: [
      { text: { en: 'Prefer hot food/drinks, like massage, warmth', hi: 'गर्म खाना/पीना पसंद, मालिश पसंद, गर्मी', mr: 'गरम अन्न/पेय आवडते, मालिश आवडते, उष्णता' }, dosha: 'V' },
      { text: { en: 'Prefer cold climate/food, like cosmetics, beauty', hi: 'ठंडा मौसम/खाना पसंद, सौंदर्य प्रसाधन', mr: 'थंड हवामान/अन्न आवडते, सौंदर्य प्रसाधने' }, dosha: 'P' },
      { text: { en: 'Fond of reading, classical texts, knowledge', hi: 'पढ़ना, शास्त्रीय ग्रंथ, ज्ञान पसंद', mr: 'वाचन, शास्त्रीय ग्रंथ, ज्ञान आवडते' }, dosha: 'K' },
    ]},
  { id: 31, tier: 2, q: { en: 'Is your bowel movement easy and satisfying?', hi: 'क्या आपका पेट साफ करना आसान और संतोषजनक है?', mr: 'तुमचे पोट साफ करणे सहज आणि समाधानकारक आहे का?' },
    options: [
      { text: { en: 'Yes — easy, quick, satisfying bowel movement', hi: 'हाँ — आसान, तेज़, संतोषजनक', mr: 'होय — सहज, वेगाने, समाधानकारक' }, dosha: 'P' },
    ], binary: true },
  { id: 32, tier: 2, q: { en: 'How is your speech style?', hi: 'आपकी बात करने की शैली कैसी है?', mr: 'तुमची बोलण्याची पद्धत कशी आहे?' },
    options: [
      { text: { en: 'Talkative, speaks fast, sometimes irrelevant', hi: 'बातूनी, तेज़ बोलना, कभी-कभी असंबंधित', mr: 'बोलका, वेगाने बोलतो, कधी असंबंधित' }, dosha: 'V' },
      { text: { en: 'Dominant, powerful, assertive speaker', hi: 'प्रभावशाली, तेज़, आक्रामक वक्ता', mr: 'प्रभावशाली, तीक्ष्ण, आक्रमक वक्ता' }, dosha: 'P' },
      { text: { en: 'Polite, soft-spoken, humble', hi: 'विनम्र, धीमी आवाज़, नम्र', mr: 'विनम्र, मृदुभाषी, नम्र' }, dosha: 'K' },
    ]},

  // TIER 3 - Binary yes/no questions
  { id: 33, tier: 3, q: { en: 'Are your teeth dry, rough, or small?', hi: 'क्या आपके दाँत रूखे, खुरदरे, या छोटे हैं?', mr: 'तुमचे दात कोरडे, खरखरीत किंवा लहान आहेत का?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'V' }], binary: true },
  { id: 34, tier: 3, q: { en: 'Do you have early grey hair (>20% before 35) or early baldness?', hi: 'क्या आपके बाल जल्दी सफेद हुए (35 से पहले >20%) या गंजापन?', mr: 'तुमचे केस लवकर पांढरे झाले (35 आधी >20%) किंवा लवकर केस गळणे?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'P' }], binary: true },
  { id: 35, tier: 3, q: { en: 'Do you feel jealous when someone close to you succeeds?', hi: 'क्या आपको करीबी व्यक्ति की सफलता पर ईर्ष्या होती है?', mr: 'जवळच्या व्यक्तीच्या यशाबद्दल तुम्हाला हेवा वाटतो का?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'V' }], binary: true },
  { id: 36, tier: 3, q: { en: 'Are you very brave and never surrender in fear?', hi: 'क्या आप बहुत बहादुर हैं और डर से कभी हार नहीं मानते?', mr: 'तुम्ही खूप धाडसी आहात आणि भीतीने कधी हार मानत नाही?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'P' }], binary: true },
  { id: 37, tier: 3, q: { en: 'Do you show strong affection and care to dependants?', hi: 'क्या आप आश्रित लोगों से गहरा स्नेह और देखभाल दिखाते हैं?', mr: 'तुम्ही अवलंबितांबद्दल तीव्र स्नेह आणि काळजी दाखवता का?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'P' }], binary: true },
  { id: 38, tier: 3, q: { en: 'Are you competitive with friends and relatives?', hi: 'क्या आप दोस्तों और रिश्तेदारों से प्रतिस्पर्धा करते हैं?', mr: 'तुम्ही मित्र आणि नातेवाईकांशी स्पर्धा करता का?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'P' }], binary: true },
  { id: 39, tier: 3, q: { en: 'Do you have a superiority complex or dismiss others\' advice?', hi: 'क्या आपमें हीनता का भाव है या दूसरों की सलाह को नज़रअंदाज़ करते हैं?', mr: 'तुम्हाला स्वतःबद्दल श्रेष्ठत्वाची भावना आहे किंवा इतरांचा सल्ला दुर्लक्षित करता?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'P' }], binary: true },
  { id: 40, tier: 3, q: { en: 'Are you harsh towards people you see as disloyal?', hi: 'क्या आप अविश्वासियों के प्रति कठोर हैं?', mr: 'तुम्ही अविश्वासू लोकांबद्दल कठोर आहात का?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'P' }], binary: true },
  { id: 41, tier: 3, q: { en: 'Do you love praise and actively seek feedback?', hi: 'क्या आपको प्रशंसा पसंद है और आप प्रतिक्रिया चाहते हैं?', mr: 'तुम्हाला कौतुक आवडते आणि तुम्ही अभिप्राय सक्रियपणे मागता?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'P' }], binary: true },
  { id: 42, tier: 3, q: { en: 'Are you a systematic planner who sets clear goals?', hi: 'क्या आप व्यवस्थित योजनाकार हैं जो स्पष्ट लक्ष्य तय करते हैं?', mr: 'तुम्ही स्पष्ट ध्येय ठरवणारे नियोजनकर्ता आहात का?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'P' }], binary: true },
  { id: 43, tier: 3, q: { en: 'Are you easily frightened with low tolerance to stress?', hi: 'क्या आप जल्दी डर जाते हैं और तनाव कम सहन कर पाते हैं?', mr: 'तुम्ही लवकर घाबरता आणि तणाव कमी सहन करू शकता?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'V' }], binary: true },
  { id: 44, tier: 3, q: { en: 'Do you forgive easily and give second chances?', hi: 'क्या आप आसानी से माफ़ करते हैं और दूसरा मौका देते हैं?', mr: 'तुम्ही सहज माफ करता आणि दुसरी संधी देता?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'K' }], binary: true },
  { id: 45, tier: 3, q: { en: 'Are you respectful to elders and polite to house-help?', hi: 'क्या आप बड़ों का सम्मान करते हैं और घर की मदद के साथ विनम्र हैं?', mr: 'तुम्ही वडिलांचा सन्मान करता आणि घरकामातील मदतीशी विनम्र आहात?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'K' }], binary: true },
  { id: 46, tier: 3, q: { en: 'Do you hold grudges or maintain strong enmity?', hi: 'क्या आप मन में रखते हैं या कड़ी दुश्मनी रखते हैं?', mr: 'तुम्ही मनात राग ठेवता किंवा तीव्र शत्रुत्व ठेवता?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'K' }], binary: true },
  { id: 47, tier: 3, q: { en: 'Do you feel shy when praised?', hi: 'क्या आपको प्रशंसा पर शर्म आती है?', mr: 'कौतुक झाल्यावर तुम्हाला लाज वाटते का?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'K' }], binary: true },
  { id: 48, tier: 3, q: { en: 'Are you generous but can say no judiciously?', hi: 'क्या आप उदार हैं लेकिन समझदारी से मना कर सकते हैं?', mr: 'तुम्ही उदार आहात पण शहाणपणाने नकार देऊ शकता?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'K' }], binary: true },
  { id: 49, tier: 3, q: { en: 'Do you exercise regularly?', hi: 'क्या आप नियमित व्यायाम करते हैं?', mr: 'तुम्ही नियमित व्यायाम करता का?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'K' }], binary: true },
  { id: 50, tier: 3, q: { en: 'Are you fond of cosmetics and ornaments?', hi: 'क्या आपको सौंदर्य प्रसाधन और आभूषण पसंद हैं?', mr: 'तुम्हाला सौंदर्य प्रसाधने आणि दागिने आवडतात का?' },
    options: [{ text: { en: 'Yes', hi: 'हाँ', mr: 'होय' }, dosha: 'P' }], binary: true },
];

// ============================================================
// RESULT DESCRIPTIONS - 7 types × 3 languages
// ============================================================
interface ResultContent {
  name: { en: string; hi: string; mr: string };
  description: { en: string; hi: string; mr: string };
  tips: { en: string; hi: string; mr: string };
}

const RESULTS: Record<string, ResultContent> = {
  'Vataj': {
    name: { en: 'Vataj Prakriti (वातज प्रकृति)', hi: 'वातज प्रकृति', mr: 'वातज प्रकृती' },
    description: {
      en: 'Vataj Prakriti is dominated by the Air and Ether elements. People of this type tend to be quick, creative, and energetic but may experience irregularity in habits. They have a light, mobile nature with variable appetite, light sleep, and fast metabolism. Their skin tends to be dry and their body frame lean.',
      hi: 'वातज प्रकृति वायु और आकाश तत्वों से प्रभावित होती है। इस प्रकार के लोग तेज़, रचनात्मक और ऊर्जावान होते हैं लेकिन उनमें अनियमितता हो सकती है। इनका स्वभाव हल्का और चंचल होता है — भूख अनियमित, नींद हल्की, और चयापय तेज़। त्वचा रूखी और शरीर पतला होता है।',
      mr: 'वातज प्रकृती वायू आणि आकाश तत्त्वांनी प्रभावित असते. या प्रकारचे लोक चपळ, सर्जनशील आणि ऊर्जावान असतात पण त्यांच्यात अनियमितता असू शकते. त्यांचा स्वभाव हलका आणि चंचल असतो — भूक अनियमित, झोप हलकी, आणि चयापय वेगवान. त्वचा कोरडी आणि शरीर सडपातळ असते.'
    },
    tips: {
      en: '• Follow a regular daily routine with fixed meal and sleep times\n• Prefer warm, moist, nourishing foods — soups, stews, cooked grains\n• Include healthy fats (ghee, sesame oil) and warm spices (ginger, cumin)\n• Avoid excessive raw/cold foods, dry snacks, and irregular eating\n• Gentle exercise like yoga, walking; oil massage (abhyanga) is beneficial\n• Keep warm, avoid excessive wind and cold exposure',
      hi: '• नियमित दिनचर्या अपनाएँ — निश्चित भोजन और नींद का समय\n• गर्म, नम, पौष्टिक भोजन — सूप, सब्ज़ियाँ, पके अनाज\n• स्वस्थ वसा (घी, तिल तेल) और गर्म मसाले (अदरक, जीरा) लें\n• अत्यधिक कच्चे/ठंडे भोजन, रूखे स्नैक्स, अनियमित खान-पान से बचें\n• हल्का व्यायाम जैसे योग, टहलना; तेल मालिश (अभ्यंग) लाभदायक\n• गर्म रहें, अत्यधिक हवा और ठंड से बचें',
      mr: '• नियमित दिनचर्या ठेवा — निश्चित जेवण आणि झोपेची वेळ\n• गरम, ओले, पौष्टिक अन्न — सूप, भाज्या, शिजवलेले धान्य\n• निरोगी चरबी (तूप, तीळ तेल) आणि गरम मसाले (आले, जीरे) घ्या\n• अतिरिक्त कच्चे/थंड अन्न, कोरडे snacks, अनियमित खाणे टाळा\n• सौम्य व्यायाम जसे योग, चालणे; तेल मालिश (अभ्यंग) लाभदायक\n• गरम राहा, अतिरिक्त वारा आणि थंडी टाळा'
    }
  },
  'Pittaj': {
    name: { en: 'Pittaj Prakriti (पित्तज प्रकृति)', hi: 'पित्तज प्रकृति', mr: 'पित्तज प्रकृती' },
    description: {
      en: 'Pittaj Prakriti is dominated by Fire and Water elements. People of this type have sharp intellect, strong digestion, and a medium build. They tend to be ambitious, focused, and warm-bodied. They may experience excess heat, acidity, or skin sensitivity. Their appetite is strong and they cannot tolerate skipping meals.',
      hi: 'पित्तज प्रकृति अग्नि और जल तत्वों से प्रभावित होती है। इस प्रकार के लोगों की बुद्धि तीक्ष्ण, पाचन शक्तिशाली, और शरीर मध्यम होता है। ये महत्वाकांक्षी, केंद्रित और गर्म स्वभाव के होते हैं। इन्हें अत्यधिक गर्मी, एसिडिटी, या त्वचा संवेदनशीलता हो सकती है। भूख तेज़ होती है और भोजन छोड़ना सहन नहीं होता।',
      mr: 'पित्तज प्रकृती अग्नी आणि जल तत्त्वांनी प्रभावित असते. या प्रकारच्या लोकांची बुद्धि तीक्ष्ण, पचनशक्ती प्रबळ, आणि शरीर मध्यम असते. ते महत्त्वाकांक्षी, केंद्रित आणि उष्ण स्वभावाचे असतात. त्यांना अतिउष्णता, आम्लता, किंवा त्वचा संवेदनशीलता असू शकते. भूक तीव्र असते आणि जेवण वगळणे सहन होत नाही.'
    },
    tips: {
      en: '• Prefer cooling foods — sweet fruits, cucumber, coconut, milk, leafy greens\n• Avoid excess spicy, sour, fried, and very hot foods\n• Eat at regular times; don\'t skip meals\n• Stay hydrated; drink cool (not ice-cold) water\n• Moderate exercise; swimming and moonlight walks are good\n• Practice calming activities — meditation, spending time near water\n• Avoid excessive sun exposure and anger-triggering situations',
      hi: '• ठंडा भोजन पसंद करें — मीठे फल, खीरा, नारियल, दूध, हरी सब्ज़ियाँ\n• अत्यधिक मसालेदार, खट्टा, तला हुआ, बहुत गर्म भोजन से बचें\n• नियमित समय पर खाएँ; भोजन न छोड़ें\n• पानी पिएँ; ठंडा (बर्फ़ वाला नहीं) पानी\n• मध्यम व्यायाम; तैराकी और चाँदनी में टहलना अच्छा\n• शांत गतिविधियाँ — ध्यान, पानी के पास समय बिताना\n• अत्यधिक धूप और क्रोध उत्पन्न करने वाली स्थितियों से बचें',
      mr: '• थंड अन्न पसंत करा — गोड फळे, काकडी, नारळ, दूध, हिरव्या भाज्या\n• अतिरिक्त तिखट, आंबट, तळलेले, खूप गरम अन्न टाळा\n• नियमित वेळी खा; जेवण वगळू नका\n• हायड्रेटेड राहा; थंड (बर्फ न घातलेले) पाणी प्या\n• मध्यम व्यायाम; पोहणे आणि चांदण्यात चालणे चांगले\n• शांत क्रियाकलाप — ध्यान, पाण्याजवळ वेळ घालवणे\n• अतिरिक्त उन्ह आणि राग येण्यासारख्या परिस्थिती टाळा'
    }
  },
  'Kaphaj': {
    name: { en: 'Kaphaj Prakriti (कफज प्रकृति)', hi: 'कफज प्रकृति', mr: 'कफज प्रकृती' },
    description: {
      en: 'Kaphaj Prakriti is dominated by Earth and Water elements. People of this type tend to have a strong, well-built body with smooth skin and thick hair. They are calm, patient, loving, and have good stamina. They may gain weight easily, sleep long, and have slower digestion. Their strength and immunity are generally excellent.',
      hi: 'कफज प्रकृति पृथ्वी और जल तत्वों से प्रभावित होती है। इस प्रकार के लोग मज़बूत, गठीत शरीर, मुलायम त्वचा और घने बाल वाले होते हैं। ये शांत, धैर्यवान, स्नेही और सहनशील होते हैं। इन्हें आसानी से वजन बढ़ सकता है, लंबी नींद आती है, और पाचन धीमा होता है। इनकी शक्ति और रोग-प्रतिरोधक क्षमता सामान्यतः उत्तम होती है।',
      mr: 'कफज प्रकृती पृथ्वी आणि जल तत्त्वांनी प्रभावित असते. या प्रकारचे लोक मजबूत, बांधेव शरीर, मऊ त्वचा आणि दाट केस असलेले असतात. ते शांत, संयमी, प्रेमळ आणि सहनशील असतात. त्यांना सहज वजन वाढू शकते, लांब झोप येते, आणि पचन हळू असते. त्यांची शक्ती आणि रोगप्रतिकार शक्ती सामान्यतः उत्कृष्ट असते.'
    },
    tips: {
      en: '• Prefer light, warm, dry foods — avoid heavy, oily, cold foods\n• Include pungent, bitter, and astringent tastes; reduce sweet/salty\n• Eat in moderation; don\'t overeat or eat late at night\n• Regular vigorous exercise is important — running, brisk walking, yoga\n• Wake early; avoid daytime sleeping\n• Stay active and engaged; seek new experiences\n• Warm spices (black pepper, ginger, turmeric) are beneficial',
      hi: '• हल्का, गर्म, रूखा भोजन पसंद करें — भारी, तैलीय, ठंडा भोजन कम\n• तीखा, कड़वा, कसैला स्वाद लें; मीठा/नमकीन कम करें\n• संयम से खाएँ; ज़्यादा न खाएँ या रात को देर से न खाएँ\n• नियमित व्यायाम ज़रूरी — दौड़ना, तेज़ चलना, योग\n• जल्दी उठें; दिन में सोने से बचें\n• सक्रिय रहें; नए अनुभव लें\n• गर्म मसाले (काली मिर्च, अदरक, हल्दी) लाभदायक',
      mr: '• हलके, गरम, कोरडे अन्न पसंत करा — जड, तेलकट, थंड अन्न कमी करा\n• तिखट, कडवट, कसळ चव घ्या; गोड/खारट कमी करा\n• मितवृत्तीने खा; जास्त खाऊ नका किंवा रात्री उशिरा खाऊ नका\n• नियमित जोरदार व्यायाम महत्त्वाचा — पळणे, वेगाने चालणे, योग\n• लवकर उठा; दिवसा झोप टाळा\n• सक्रिय राहा; नवीन अनुभव घ्या\n• गरम मसाले (काळी मिरी, आले, हळद) लाभदायक'
    }
  },
  'Vata-Pitta': {
    name: { en: 'Vata-Pitta Dwidoshaja (वात-पित्त द्विदोषज)', hi: 'वात-पित्त द्विदोषज प्रकृति', mr: 'वात-पित्त द्विदोषज प्रकृती' },
    description: {
      en: 'This dual-dosha type combines the quick, mobile nature of Vata with the sharp, fiery qualities of Pitta. These individuals are energetic, intelligent, and creative, but may experience both restlessness and intensity. They tend to have a lean-to-medium build with variable appetite and strong digestion.',
      hi: 'यह द्विदोष प्रकार वात की तेज़, चंचल प्रकृति को पित्त की तीक्ष्ण, अग्निल विशेषताओं से जोड़ता है। ये लोग ऊर्जावान, बुद्धिमान और रचनात्मक होते हैं, लेकिन इनमें बेचैनी और तीव्रता दोनों हो सकती है। इनका शरीर पतला-से-मध्यम, भूख परिवर्तनशील, और पाचन शक्तिशाली होता है।',
      mr: 'हा द्विदोष प्रकार वाताची चपळ, चंचल प्रकृती आणि पित्ताची तीक्ष्ण, अग्नी गुणधर्म एकत्र करतो. हे लोक ऊर्जावान, बुद्धिमान आणि सर्जनशील असतात, पण त्यांच्यात अस्वस्थता आणि तीव्रता दोन्ही असू शकते. त्यांचे शरीर सडपातळ-ते-मध्यम, भूक बदलणारी, आणि पचन प्रबळ असते.'
    },
    tips: {
      en: '• Maintain a regular routine to calm Vata while cooling Pitta\n• Eat warm but not too spicy foods; include sweet, bitter tastes\n• Avoid excessive caffeine, very hot spices, and raw/cold foods\n• Moderate exercise — yoga, swimming, gentle walks\n• Practice meditation and pranayama for balance\n• Keep both warm and cool — avoid extremes of temperature',
      hi: '• वात को शांत करने और पित्त को ठंडा रखने के लिए नियमित दिनचर्या\n• गर्म लेकिन बहुत मसालेदार नहीं; मीठा, कड़वा स्वाद लें\n• अत्यधिक कैफीन, बहुत तेज़ मसाले, कच्चे/ठंडे भोजन से बचें\n• मध्यम व्यायाम — योग, तैराकी, हल्की सैर\n• संतुलन के लिए ध्यान और प्राणायाम करें\n• गर्म और ठंडा दोनों रखें — तापमान की चरम सीमा से बचें',
      mr: '• वात शांत करण्यासाठी आणि पित्त थंड ठेवण्यासाठी नियमित दिनचर्या\n• गरम पण खूप तिखट नाही; गोड, कडवट चव घ्या\n• अतिरिक्त कॅफीन, खूप तिखट मसाले, कच्चे/थंड अन्न टाळा\n• मध्यम व्यायाम — योग, पोहणे, सौम्य चालणे\n• समतोलासाठी ध्यान आणि प्राणायाम करा\n• गरम आणि थंड दोन्ही ठेवा — तापमानाच्या टोकापासून दूर राहा'
    }
  },
  'Pitta-Kapha': {
    name: { en: 'Pitta-Kapha Dwidoshaja (पित्त-कफ द्विदोषज)', hi: 'पित्त-कफ द्विदोषज प्रकृति', mr: 'पित्त-कफ द्विदोषज प्रकृती' },
    description: {
      en: 'This dual-dosha type blends the fiery intensity of Pitta with the steady, grounded nature of Kapha. These individuals are strong, determined, and have good endurance. They tend to have a medium-to-heavy build with steady appetite and strong metabolism. They can be both ambitious and patient.',
      hi: 'यह द्विदोष प्रकार पित्त की अग्निल तीव्रता को कफ की स्थिर, आधारभूत प्रकृति से मिलाता है। ये लोग मज़बूत, दृढ़-संकल्प और सहनशील होते हैं। इनका शरीर मध्यम-से-भारी, भूख स्थिर, और चयापय शक्तिशाली होता है। ये महत्वाकांक्षी और धैर्यवान दोनों हो सकते हैं।',
      mr: 'हा द्विदोष प्रकार पित्ताची अग्नी तीव्रता आणि कफची स्थिर, आधारभूत प्रकृती एकत्र करतो. हे लोक मजबूत, दृढ-संकल्प आणि सहनशील असतात. त्यांचे शरीर मध्यम-ते-जड, भूक स्थिर, आणि चयापय प्रबळ असते. ते महत्त्वाकांक्षी आणि संयमी दोन्ही असू शकतात.'
    },
    tips: {
      en: '• Balance Pitta heat with cooling foods while keeping Kapha light\n• Include bitter, astringent, pungent tastes; reduce oily/heavy foods\n• Regular vigorous exercise to prevent Kapha accumulation\n• Avoid late meals and excessive daytime sleep\n• Stay active but also practice calming activities\n• Warm spices in moderation; avoid very hot and very cold extremes',
      hi: '• पित्त की गर्मी को ठंडे भोजन से संतुलित करें, कफ को हल्का रखें\n• कड़वा, कसैला, तीखा स्वाद; तैलीय/भारी भोजन कम करें\n• कफ जमाव रोकने के लिए नियमित व्यायाम\n• देर रात भोजन और दिन में अत्यधिक नींद से बचें\n• सक्रिय रहें लेकिन शांत गतिविधियाँ भी करें\n• मसाले संयम से; बहुत गर्म और बहुत ठंडा दोनों से बचें',
      mr: '• पित्ताची उष्णता थंड अन्नाने संतुलित करा, कफ हलका ठेवा\n• कडवट, कसळ, तिखट चव; तेलकट/जड अन्न कमी करा\n• कफ साठवाण टाळण्यासाठी नियमित जोरदार व्यायाम\n• उशिरा जेवण आणि दिवसा अतिरिक्त झोप टाळा\n• सक्रिय राहा पण शांत क्रियाकलापही करा\n• मसाले मितप्रमाणात; खूप गरम आणि खूप थंड दोन्ही टाळा'
    }
  },
  'Vata-Kapha': {
    name: { en: 'Vata-Kapha Dwidoshaja (वात-कफ द्विदोषज)', hi: 'वात-कफ द्विदोषज प्रकृति', mr: 'वात-कफ द्विदोषज प्रकृती' },
    description: {
      en: 'This dual-dosha type combines the light, mobile quality of Vata with the steady, heavy nature of Kapha. These individuals may alternate between high energy and lethargy. They tend to have a medium build with variable appetite and steady but slow digestion. They are creative yet grounded.',
      hi: 'यह द्विदोष प्रकार वात की हल्की, चंचल गुणवत्ता को कफ की स्थिर, भारी प्रकृति से जोड़ता है। ये लोग कभी ऊर्जावान और कभी सुस्त हो सकते हैं। इनका शरीर मध्यम, भूख परिवर्तनशील, और पाचन स्थिर लेकिन धीमा होता है। ये रचनात्मक लेकिन आधारभूत होते हैं।',
      mr: 'हा द्विदोष प्रकार वाताची हलकी, चंचल गुणवत्ता आणि कफची स्थिर, जड प्रकृती एकत्र करतो. हे लोक कधी ऊर्जावान आणि कधी सुस्त असू शकतात. त्यांचे शरीर मध्यम, भूक बदलणारी, आणि पचन स्थिर पण हळू असते. ते सर्जनशील पण आधारभूत असतात.'
    },
    tips: {
      en: '• Maintain regular routine to balance both Vata irregularity and Kapha inertia\n• Warm, light, easily digestible foods; avoid cold, heavy, oily foods\n• Include warming spices (ginger, black pepper, cinnamon)\n• Regular moderate exercise — walking, yoga, light cardio\n• Avoid daytime sleeping; wake up early\n• Stay warm and dry; avoid cold, damp environments',
      hi: '• वात की अनियमितता और कफ की जड़ता दोनों को संतुलित करने के लिए नियमित दिनचर्या\n• गर्म, हल्का, पचने योग्य भोजन; ठंडा, भारी, तैलीय से बचें\n• गर्म मसाले (अदरक, काली मिर्च, दालचीनी)\n• नियमित मध्यम व्यायाम — टहलना, योग, हल्का कार्डियो\n• दिन में सोने से बचें; जल्दी उठें\n• गर्म और सूखे रहें; ठंडी, नम जगह से बचें',
      mr: '• वाताची अनियमितता आणि कफची जडता दोन्ही संतुलित करण्यासाठी नियमित दिनचर्या\n• गरम, हलके, पचण्यासारखे अन्न; थंड, जड, तेलकट टाळा\n• गरम मसाले (आले, काळी मिरी, दालचिनी)\n• नियमित मध्यम व्यायाम — चालणे, योग, हलका कार्डिओ\n• दिवसा झोप टाळा; लवकर उठा\n• गरम आणि कोरडे राहा; थंड, ओलसर वातावरण टाळा'
    }
  },
  'Sama': {
    name: { en: 'Sama Prakriti — Tridoshaja (सम प्रकृति — त्रिदोषज)', hi: 'सम प्रकृति — त्रिदोषज', mr: 'सम प्रकृती — त्रिदोषज' },
    description: {
      en: 'Sama Prakriti (Tridoshaja) represents a balanced state where all three doshas — Vata, Pitta, and Kapha — are in roughly equal proportion. This is considered an ideal, harmonious constitution. People of this type tend to have balanced physical features, moderate appetite and digestion, steady emotions, and good overall health. They adapt well to different situations.',
      hi: 'सम प्रकृति (त्रिदोषज) एक संतुलित अवस्था है जहाँ तीनों दोष — वात, पित्त, और कफ — लगभग समान अनुपात में होते हैं। इसे आदर्श, सामंजस्यपूर्ण संरचना माना जाता है। इस प्रकार के लोगों में संतुलित शारीरिक विशेषताएँ, मध्यम भूख और पाचन, स्थिर भावनाएँ, और अच्छा सामान्य स्वास्थ्य होता है। ये विभिन्न परिस्थितियों में अच्छी तरह अनुकूलित होते हैं।',
      mr: 'सम प्रकृती (त्रिदोषज) ही एक संतुलित अवस्था आहे जिथे तिन्ही दोष — वात, पित्त, आणि कफ — अंदाजे समान प्रमाणात असतात. हे आदर्श, सुसंवादित संरचना मानले जाते. या प्रकारच्या लोकांमध्ये संतुलित शारीरिक वैशिष्ट्ये, मध्यम भूक आणि पचन, स्थिर भावना, आणि चांगले सामान्य आरोग्य असते. ते विविध परिस्थितींशी चांगले जुळवून घेतात.'
    },
    tips: {
      en: '• Maintain seasonal routine (ritucharya) — adjust diet and lifestyle with seasons\n• Eat a balanced diet with all six tastes in moderation\n• Continue regular exercise appropriate to the season\n• Practice meditation and mindfulness for mental balance\n• Avoid extreme foods, habits, or environments\n• Follow natural daily rhythm — wake with sunrise, sleep by 10-11 PM',
      hi: '• ऋतुचर्या अपनाएँ — ऋतु के अनुसार आहार और जीवनशैली बदलें\n• सभी छह स्वाद संयम से लें — संतुलित भोजन\n• ऋतु के अनुसार नियमित व्यायाम करें\n• मानसिक संतुलन के लिए ध्यान और सावधानी का अभ्यास करें\n• चरम भोजन, आदतें, या वातावरण से बचें\n• प्राकृतिक दैनिक लय — सूर्योदय पर जागें, 10-11 बजे सो जाएँ',
      mr: '• ऋतुचर्या पाळा — ऋतूनुसार आहार आणि जीवनशैली बदला\n• सर्व सहा चव मितप्रमाणात घ्या — संतुलित अन्न\n• ऋतूनुसार नियमित व्यायाम करा\n• मानसिक समतोलासाठी ध्यान आणि सावधगिरीचा अभ्यास करा\n• टोकाचे अन्न, सवयी, किंवा वातावरण टाळा\n• नैसर्गिक दैनिक लय — सूर्योदयाला उठा, 10-11 वाजता झोपा'
    }
  },
};

// ============================================================
// CLASSIFICATION CONSTANTS (easy to edit)
// ============================================================
const EKA_THRESHOLD = 65; // top dosha ≥ 65% → Ekdoshaja
const DWI_LOW_THRESHOLD = 20; // lowest dosha ≤ 20% → Dwidoshaja
const EARLY_STOP_EKA_MIN = 14;
const EARLY_STOP_EKA_PCT = 72;
const EARLY_STOP_EKA_STABLE = 3;
const EARLY_STOP_DWI_MIN = 20;
const EARLY_STOP_DWI_LOW = 15;
const EARLY_STOP_DWI_TOP = 30;
const EARLY_STOP_DWI_STABLE = 4;
const EARLY_STOP_SAMA_MIN = 28;
const EARLY_STOP_SAMA_LOW = 27;
const EARLY_STOP_SAMA_HIGH = 40;
const EARLY_STOP_SAMA_STABLE = 4;
const BINARY_SKIP_THRESHOLD = 12; // dosha < 12% after ≥ 15 answers
const BINARY_SKIP_ANSWERS = 15;

// ============================================================
// SCORING & CLASSIFICATION FUNCTIONS
// ============================================================

type Dosha = 'V' | 'P' | 'K';

interface Scores {
  V: number;
  P: number;
  K: number;
}

interface Answer {
  questionId: number;
  dosha: Dosha | null; // null = not sure
}

function computeScores(answers: Answer[]): Scores {
  const scores: Scores = { V: 0, P: 0, K: 0 };
  for (const a of answers) {
    if (a.dosha) scores[a.dosha]++;
  }
  return scores;
}

function computePercentages(scores: Scores): { V: number; P: number; K: number } {
  const T = scores.V + scores.P + scores.K;
  if (T === 0) return { V: 33.3, P: 33.3, K: 33.4 };
  return {
    V: (scores.V / T) * 100,
    P: (scores.P / T) * 100,
    K: (scores.K / T) * 100,
  };
}

function classify(scores: Scores): string {
  const pcts = computePercentages(scores);
  const doshas: Dosha[] = ['V', 'P', 'K'];
  const sorted = [...doshas].sort((a, b) => pcts[b] - pcts[a]);
  const top = sorted[0];
  const mid = sorted[1];
  const low = sorted[2];

  // EKA: top ≥ 65%
  if (pcts[top] >= EKA_THRESHOLD) {
    const names: Record<Dosha, string> = { V: 'Vataj', P: 'Pittaj', K: 'Kaphaj' };
    return names[top];
  }

  // DWI: lowest ≤ 20%
  if (pcts[low] <= DWI_LOW_THRESHOLD) {
    const pair = [top, mid].sort().join('-');
    const names: Record<string, string> = {
      'P-V': 'Vata-Pitta', 'V-P': 'Vata-Pitta',
      'K-P': 'Pitta-Kapha', 'P-K': 'Pitta-Kapha',
      'K-V': 'Vata-Kapha', 'V-K': 'Vata-Kapha',
    };
    return names[pair] || 'Sama';
  }

  // SAMA: all roughly equal
  return 'Sama';
}

// Get stable classification history (last N answers)
function getRecentClassifications(answers: Answer[], n: number): string[] {
  const results: string[] = [];
  for (let i = Math.max(0, answers.length - n); i <= answers.length; i++) {
    if (i < 3) continue; // need at least some answers
    const subset = answers.slice(0, i);
    const sc = computeScores(subset);
    if (sc.V + sc.P + sc.K > 0) {
      results.push(classify(sc));
    }
  }
  return results;
}

// ============================================================
// ADAPTIVE QUESTION SELECTION
// ============================================================

function pickNextQuestion(
  answers: Answer[],
  askedIds: Set<number>,
  skipDreams: boolean
): Question | null {
  const scores = computeScores(answers);
  const totalInformative = scores.V + scores.P + scores.K;
  const pcts = computePercentages(scores);

  // Get available questions by tier
  const available = QUESTIONS.filter(q => {
    if (askedIds.has(q.id)) return false;
    if (q.skipIfNoDreams && skipDreams) return false;
    return true;
  });

  if (available.length === 0) return null;

  // If fewer than 6 answers, just go through T1 in order
  if (totalInformative < 6) {
    const t1 = available.filter(q => q.tier === 1);
    if (t1.length > 0) return t1[0];
    // Fall through to smart selection if no T1 left
  }

  // Smart selection: find top 2 doshas, prefer questions that differentiate them
  const doshas: Dosha[] = ['V', 'P', 'K'];
  const sorted = [...doshas].sort((a, b) => pcts[b] - pcts[a]);
  const top2: Dosha[] = [sorted[0], sorted[1]];

  // Check if we should skip binary questions
  const useBinary = available.filter(q => q.tier <= 2).length === 0 ||
    totalInformative >= BINARY_SKIP_ANSWERS;

  // Prefer T1/T2 questions that have options for BOTH top doshas
  const nonBinary = available.filter(q => !q.binary);
  const tier12 = nonBinary.filter(q => q.tier <= 2);

  // Score each question by how well it differentiates top 2
  const scored = tier12.map(q => {
    const optionDoshas = q.options.map(o => o.dosha).filter(Boolean);
    const coversTop1 = optionDoshas.includes(top2[0]);
    const coversTop2 = optionDoshas.includes(top2[1]);
    let score = 0;
    if (coversTop1) score += 2;
    if (coversTop2) score += 2;
    if (coversTop1 && coversTop2) score += 3; // bonus for covering both
    // Prefer lower tier
    score += (3 - q.tier);
    return { q, score };
  });

  scored.sort((a, b) => b.score - a.score);

  if (scored.length > 0 && scored[0].score > 0) {
    return scored[0].q;
  }

  // If no good T1/T2 match, try binary questions
  if (useBinary) {
    const binaryQs = available.filter(q => q.binary);
    // Skip binary if its dosha is already out of race
    const filtered = binaryQs.filter(q => {
      const d = q.options[0]?.dosha;
      if (!d) return false;
      if (totalInformative >= BINARY_SKIP_ANSWERS && pcts[d] < BINARY_SKIP_THRESHOLD) return false;
      return true;
    });
    if (filtered.length > 0) return filtered[0];
  }

  // Fallback: any remaining question
  if (available.length > 0) return available[0];
  return null;
}

// ============================================================
// EARLY STOP LOGIC
// ============================================================

function shouldStop(answers: Answer[]): boolean {
  const scores = computeScores(answers);
  const totalInformative = scores.V + scores.P + scores.K;
  const pcts = computePercentages(scores);
  const doshas: Dosha[] = ['V', 'P', 'K'];
  const sorted = [...doshas].sort((a, b) => pcts[b] - pcts[a]);
  const currentClass = classify(scores);

  // Check EKA early stop
  if (totalInformative >= EARLY_STOP_EKA_MIN && pcts[sorted[0]] >= EARLY_STOP_EKA_PCT) {
    const recent = getRecentClassifications(answers, EARLY_STOP_EKA_STABLE + 1);
    if (recent.length >= EARLY_STOP_EKA_STABLE) {
      const lastN = recent.slice(-EARLY_STOP_EKA_STABLE);
      if (lastN.every(c => c === currentClass && c !== 'Sama')) {
        // Verify it's EKA type
        if (['Vataj', 'Pittaj', 'Kaphaj'].includes(currentClass)) {
          return true;
        }
      }
    }
  }

  // Check DWI early stop
  if (totalInformative >= EARLY_STOP_DWI_MIN &&
      pcts[sorted[2]] <= EARLY_STOP_DWI_LOW &&
      pcts[sorted[0]] >= EARLY_STOP_DWI_TOP &&
      pcts[sorted[1]] >= EARLY_STOP_DWI_TOP) {
    const recent = getRecentClassifications(answers, EARLY_STOP_DWI_STABLE + 1);
    if (recent.length >= EARLY_STOP_DWI_STABLE) {
      const lastN = recent.slice(-EARLY_STOP_DWI_STABLE);
      if (lastN.every(c => c === currentClass && c.includes('-'))) {
        return true;
      }
    }
  }

  // Check SAMA early stop
  if (totalInformative >= EARLY_STOP_SAMA_MIN &&
      pcts.V >= EARLY_STOP_SAMA_LOW && pcts.V <= EARLY_STOP_SAMA_HIGH &&
      pcts.P >= EARLY_STOP_SAMA_LOW && pcts.P <= EARLY_STOP_SAMA_HIGH &&
      pcts.K >= EARLY_STOP_SAMA_LOW && pcts.K <= EARLY_STOP_SAMA_HIGH) {
    const recent = getRecentClassifications(answers, EARLY_STOP_SAMA_STABLE + 1);
    if (recent.length >= EARLY_STOP_SAMA_STABLE) {
      const lastN = recent.slice(-EARLY_STOP_SAMA_STABLE);
      if (lastN.every(c => c === 'Sama')) {
        return true;
      }
    }
  }

  // All questions exhausted
  const askedIds = new Set(answers.map(a => a.questionId));
  const remaining = QUESTIONS.filter(q => !askedIds.has(q.id));
  if (remaining.length === 0) return true;

  return false;
}

// ============================================================
// SVG DECORATIVE COMPONENTS
// ============================================================

function LeafSVG({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M17 8C8 10 5.9 16.17 3.82 21.34L5.71 22L6.66 19.7C7.14 19.35 9 18 12 18C15 18 17 16 17 13V8Z" fill="currentColor" opacity="0.7"/>
      <path d="M20 2C20 2 19 4 17 6C15 8 12 8 12 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
  );
}

function LotusSVG({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16 28C16 28 8 22 8 16C8 12 11 8 16 4C21 8 24 12 24 16C24 22 16 28 16 28Z" fill="currentColor" opacity="0.3"/>
      <path d="M16 28C16 28 4 20 4 14C4 10 8 8 12 8" stroke="currentColor" strokeWidth="1" opacity="0.5"/>
      <path d="M16 28C16 28 28 20 28 14C28 10 24 8 20 8" stroke="currentColor" strokeWidth="1" opacity="0.5"/>
      <circle cx="16" cy="16" r="2" fill="currentColor" opacity="0.6"/>
    </svg>
  );
}

function MortarPestleSVG({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 20C8 20 6 28 16 28C26 28 24 20 24 20" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      <ellipse cx="16" cy="20" rx="8" ry="3" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M20 8L14 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <circle cx="21" cy="7" r="2" fill="currentColor" opacity="0.6"/>
    </svg>
  );
}

// ============================================================
// MAIN APP COMPONENT
// ============================================================

type Lang = 'en' | 'hi' | 'mr';
type Screen = 'lang' | 'intro' | 'quiz' | 'result';

export default function App() {
  const [lang, setLang] = useState<Lang>('en');
  const [screen, setScreen] = useState<Screen>('lang');
  const [userInfo, setUserInfo] = useState({ name: '', age: '', gender: '' });
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [askedIds, setAskedIds] = useState<Set<number>>(new Set());
  const [currentQ, setCurrentQ] = useState<Question | null>(null);
  const [stopped, setStopped] = useState(false);
  const [skipDreams, setSkipDreams] = useState(false);
  const [animating, setAnimating] = useState(false);

  const t = I18N[lang];

  // Create floating particles
  useEffect(() => {
    const particles: HTMLDivElement[] = [];
    for (let i = 0; i < 20; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      particle.style.left = `${Math.random() * 100}%`;
      particle.style.animationDelay = `${Math.random() * 15}s`;
      particle.style.animationDuration = `${10 + Math.random() * 10}s`;
      document.body.appendChild(particle);
      particles.push(particle);
    }
    return () => {
      particles.forEach(p => p.remove());
    };
  }, []);

  // Initialize first question
  useEffect(() => {
    if (screen === 'quiz' && !currentQ && !stopped) {
      const q = pickNextQuestion(answers, askedIds, skipDreams);
      setCurrentQ(q);
    }
  }, [screen, currentQ, stopped, answers, askedIds, skipDreams]);

  const handleLangSelect = (l: Lang) => {
    setLang(l);
    setScreen('intro');
  };

  const handleStartQuiz = () => {
    setScreen('quiz');
    setAnswers([]);
    setAskedIds(new Set());
    setCurrentQ(null);
    setStopped(false);
    setSkipDreams(false);
  };

  const handleAnswer = (dosha: Dosha | null) => {
    if (!currentQ) return;

    setAnimating(true);
    setTimeout(() => {
      const newAnswers = [...answers, { questionId: currentQ.id, dosha }];
      const newAskedIds = new Set(askedIds);
      newAskedIds.add(currentQ.id);

      // Check dream skip
      let newSkipDreams = skipDreams;
      if (currentQ.id === 29 && dosha === null) {
        // "Not sure" on dreams → could mean no dreams, but we only skip if explicitly
      }

      setAnswers(newAnswers);
      setAskedIds(newAskedIds);
      setSkipDreams(newSkipDreams);

      // Check early stop
      if (shouldStop(newAnswers)) {
        setStopped(true);
        setCurrentQ(null);
        setScreen('result');
      } else {
        const nextQ = pickNextQuestion(newAnswers, newAskedIds, newSkipDreams);
        if (!nextQ) {
          setStopped(true);
          setScreen('result');
        } else {
          setCurrentQ(nextQ);
        }
      }
      setAnimating(false);
    }, 300);
  };

  const handleBack = () => {
    if (answers.length === 0) return;
    setAnimating(true);
    setTimeout(() => {
      const newAnswers = answers.slice(0, -1);
      const removedAnswer = answers[answers.length - 1];
      const newAskedIds = new Set(askedIds);
      newAskedIds.delete(removedAnswer.questionId);
      setAnswers(newAnswers);
      setAskedIds(newAskedIds);
      setStopped(false);

      // Recompute next question
      const nextQ = pickNextQuestion(newAnswers, newAskedIds, skipDreams);
      setCurrentQ(nextQ);
      setAnimating(false);
    }, 200);
  };

  const handleContinue = () => {
    setStopped(false);
    setScreen('quiz');
    setCurrentQ(null);
  };

  const handleRetake = () => {
    setAnswers([]);
    setAskedIds(new Set());
    setCurrentQ(null);
    setStopped(false);
    setSkipDreams(false);
    setScreen('intro');
  };

  const scores = useMemo(() => computeScores(answers), [answers]);
  const pcts = useMemo(() => computePercentages(scores), [scores]);
  const resultType = useMemo(() => classify(scores), [scores]);
  const totalAnswered = scores.V + scores.P + scores.K;

  // Language switcher in header
  const LangSwitcher = () => (
    <div className="flex items-center gap-3 no-print">
      <span className="text-sm text-white/60">{t.langSwitch}:</span>
      {(['en', 'hi', 'mr'] as Lang[]).map(l => (
        <button
          key={l}
          onClick={() => setLang(l)}
          className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-all ${
            lang === l
              ? 'bg-gradient-to-r from-[var(--gold)] to-[#b8941f] text-[var(--deep-navy)] shadow-lg shadow-[var(--gold-glow)]'
              : 'bg-white/5 text-white/70 hover:bg-white/10 hover:text-white border border-white/10'
          }`}
        >
          {l === 'en' ? 'EN' : l === 'hi' ? 'हिं' : 'मर'}
        </button>
      ))}
    </div>
  );

  // ============================================================
  // RENDER SCREENS
  // ============================================================

  if (screen === 'lang') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 relative z-10">
        <div className="text-center mb-12 animate-fade-in-up">
          <div className="flex justify-center gap-6 mb-6">
            <div className="text-[var(--gold)] animate-pulse-glow rounded-full p-4">
              <LotusSVG className="w-16 h-16" />
            </div>
          </div>
          <h1 className="heading-font text-5xl md:text-7xl mb-4 gold-text">
            {I18N.en.appTitle}
          </h1>
          <h2 className="heading-font text-3xl md:text-4xl text-white/80 mb-2">
            {I18N.hi.appTitle}
          </h2>
          <h2 className="heading-font text-3xl md:text-4xl text-white/80 mb-6">
            {I18N.mr.appTitle}
          </h2>
          <p className="text-white/60 text-lg tracking-wide">{I18N.en.appSubtitle}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl w-full animate-fade-in-up" style={{animationDelay: '0.2s'}}>
          {([
            { lang: 'en' as Lang, label: 'English', sub: 'Continue in English' },
            { lang: 'hi' as Lang, label: 'हिंदी', sub: 'हिंदी में जारी रखें' },
            { lang: 'mr' as Lang, label: 'मराठी', sub: 'मराठीत चालू ठेवा' },
          ]).map((item, idx) => (
            <button
              key={item.lang}
              onClick={() => handleLangSelect(item.lang)}
              className="lang-card focus:outline-none"
              tabIndex={0}
              style={{animationDelay: `${idx * 0.1}s`}}
            >
              <div className="relative z-10">
                <div className="text-4xl font-bold mb-3 heading-font gold-text">
                  {item.label}
                </div>
                <div className="text-sm text-white/60">{item.sub}</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (screen === 'intro') {
    return (
      <div className="min-h-screen flex flex-col relative z-10">
        {/* Header */}
        <header className="glass-card mx-4 mt-4 p-4 flex items-center justify-between no-print">
          <h1 className="heading-font text-xl gold-text">{t.appTitle}</h1>
          <LangSwitcher />
        </header>

        <main className="flex-1 flex flex-col items-center justify-center p-4 md:p-8">
          <div className="glass-card p-8 md:p-12 max-w-2xl w-full animate-fade-in-up">
            <div className="flex justify-center mb-6">
              <div className="text-[var(--gold)] animate-pulse-glow rounded-full p-4">
                <LotusSVG className="w-16 h-16" />
              </div>
            </div>
            <h2 className="heading-font text-3xl md:text-4xl text-center gold-text mb-6">
              {t.introTitle}
            </h2>
            <p className="text-white/80 leading-relaxed mb-8 text-center text-lg">
              {t.introText}
            </p>

            {/* Disclaimer */}
            <div className="bg-[rgba(244,63,94,0.1)] border border-[rgba(244,63,94,0.3)] rounded-2xl p-5 mb-8 backdrop-blur-sm">
              <p className="text-sm text-[var(--rose)] leading-relaxed flex items-start gap-2">
                <span className="text-xl">⚕️</span>
                <span>{t.disclaimer}</span>
              </p>
            </div>

            {/* Optional info */}
            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4 text-white/90">{t.optionalInfo}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <input
                  type="text"
                  placeholder={t.name}
                  value={userInfo.name}
                  onChange={e => setUserInfo({ ...userInfo, name: e.target.value })}
                />
                <input
                  type="number"
                  placeholder={t.age}
                  value={userInfo.age}
                  onChange={e => setUserInfo({ ...userInfo, age: e.target.value })}
                />
                <select
                  value={userInfo.gender}
                  onChange={e => setUserInfo({ ...userInfo, gender: e.target.value })}
                >
                  <option value="">{t.gender}</option>
                  <option value="male">{t.male}</option>
                  <option value="female">{t.female}</option>
                  <option value="other">{t.other}</option>
                </select>
              </div>
            </div>

            <div className="flex justify-center">
              <button onClick={handleStartQuiz} className="btn-primary text-lg">
                {t.start} →
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  // Quiz loading state (transitioning between questions)
  if (screen === 'quiz' && !currentQ && !stopped) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 relative z-10">
        <div className="glass-card p-10 text-center animate-fade-in-up">
          <div className="text-5xl mb-4 animate-pulse-glow inline-block rounded-full p-4">🕉️</div>
          <p className="text-white/70 heading-font text-xl">
            {lang === 'en' ? 'Preparing next question...' : lang === 'hi' ? 'अगला प्रश्न तैयार हो रहा है...' : 'पुढील प्रश्न तयार करत आहे...'}
          </p>
        </div>
      </div>
    );
  }

  if (screen === 'quiz' && currentQ) {
    const informativeCount = totalAnswered;
    const progressPct = Math.min((informativeCount / 25) * 100, 95); // soft estimate

    return (
      <div className="min-h-screen flex flex-col relative z-10">
        {/* Header */}
        <header className="glass-card mx-4 mt-4 p-4 flex items-center justify-between no-print">
          <h1 className="heading-font text-xl gold-text">{t.appTitle}</h1>
          <LangSwitcher />
        </header>

        <main className="flex-1 flex flex-col items-center p-4 md:p-8">
          <div className="glass-card p-6 md:p-10 max-w-2xl w-full">
            {/* Progress */}
            <div className="mb-8">
              <div className="flex justify-between items-center mb-3">
                <span className="text-sm text-white/60 font-medium">
                  {t.question} #{informativeCount + 1}
                </span>
                <span className="text-xs text-[var(--gold)] font-semibold bg-[var(--gold)]/10 px-3 py-1 rounded-full">
                  Tier {currentQ.tier}
                </span>
              </div>
              <div className="progress-bar-bg">
                <div className="progress-bar-fill" style={{ width: `${progressPct}%` }} />
              </div>
            </div>

            {/* Question */}
            <div className={`mb-8 ${animating ? 'opacity-0 translate-x-4' : 'opacity-100 translate-x-0'} transition-all duration-300`}>
              <h2 className="heading-font text-2xl md:text-3xl text-white leading-relaxed">
                {currentQ.q[lang]}
              </h2>
            </div>

            {/* Options */}
            <div className={`space-y-4 ${animating ? 'opacity-0 pointer-events-none' : 'opacity-100'} transition-all duration-300`}>
              {currentQ.options.map((opt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAnswer(opt.dosha)}
                  className="option-btn w-full"
                  tabIndex={0}
                >
                  <span className="relative z-10 flex items-center gap-4">
                    <span className="w-9 h-9 rounded-full border-2 border-[var(--gold)] flex items-center justify-center text-sm font-bold text-[var(--gold)] flex-shrink-0 bg-[var(--gold)]/10">
                      {currentQ.binary ? '✓' : String.fromCharCode(65 + idx)}
                    </span>
                    <span className="text-white/90 text-lg">{opt.text[lang]}</span>
                  </span>
                </button>
              ))}

              {/* Binary: show "No" option; Non-binary: show "Not sure / Neither" */}
              {currentQ.binary ? (
                <button
                  onClick={() => handleAnswer(null)}
                  className="option-btn w-full opacity-60"
                  tabIndex={0}
                >
                  <span className="relative z-10 flex items-center gap-4">
                    <span className="w-9 h-9 rounded-full border-2 border-white/30 flex items-center justify-center text-sm text-white/50 flex-shrink-0">
                      ✗
                    </span>
                    <span className="text-white/60 text-lg">{t.no}</span>
                  </span>
                </button>
              ) : (
                <button
                  onClick={() => handleAnswer(null)}
                  className="option-btn w-full opacity-60"
                  tabIndex={0}
                >
                  <span className="relative z-10 flex items-center gap-4">
                    <span className="w-9 h-9 rounded-full border-2 border-white/30 flex items-center justify-center text-sm text-white/50 flex-shrink-0">
                      ?
                    </span>
                    <span className="italic text-white/60 text-lg">{t.notSure}</span>
                  </span>
                </button>
              )}
            </div>

            {/* Back button */}
            {answers.length > 0 && (
              <div className="mt-8 flex justify-start no-print">
                <button onClick={handleBack} className="btn-secondary flex items-center gap-2">
                  ← {t.back}
                </button>
              </div>
            )}
          </div>
        </main>
      </div>
    );
  }

  // RESULT SCREEN
  const result = RESULTS[resultType] || RESULTS['Sama'];
  const remainingQs = QUESTIONS.filter(q => !askedIds.has(q.id) && !(q.skipIfNoDreams && skipDreams));
  const canContinue = remainingQs.length > 0;

  return (
    <div className="min-h-screen flex flex-col relative z-10">
      {/* Header */}
      <header className="glass-card mx-4 mt-4 p-4 flex items-center justify-between no-print">
        <h1 className="heading-font text-xl gold-text">{t.appTitle}</h1>
        <LangSwitcher />
      </header>

      <main className="flex-1 flex flex-col items-center p-4 md:p-8">
        <div className="glass-card p-8 md:p-12 max-w-2xl w-full animate-fade-in-up">
          {/* Title */}
          <div className="text-center mb-10">
            <div className="flex justify-center gap-4 mb-4">
              <div className="text-[var(--gold)] animate-pulse-glow rounded-full p-4">
                <LotusSVG className="w-14 h-14" />
              </div>
            </div>
            <h2 className="heading-font text-3xl md:text-4xl gold-text mb-3">
              {t.resultTitle}
            </h2>
            {userInfo.name && (
              <p className="text-white/70 text-lg">{userInfo.name}</p>
            )}
            <p className="text-xs text-white/50 mt-2">
              {t.printDate}: {new Date().toLocaleDateString(lang === 'en' ? 'en-IN' : lang === 'hi' ? 'hi-IN' : 'mr-IN')}
            </p>
          </div>

          {/* Prakriti Type */}
          <div className="text-center mb-10">
            <p className="text-sm text-white/60 mb-2 uppercase tracking-wider">{t.yourType}</p>
            <h3 className="heading-font text-3xl md:text-4xl gold-text font-bold">
              {result.name[lang]}
            </h3>
          </div>

          {/* Dosha Bars */}
          <div className="space-y-6 mb-10">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="font-semibold text-[var(--sapphire)] text-lg">
                  {t.vata} (वात)
                </span>
                <span className="text-lg font-bold text-white/90">{Math.round(pcts.V)}%</span>
              </div>
              <div className="dosha-bar-bg">
                <div className="dosha-bar-fill dosha-bar-vata" style={{ width: `${pcts.V}%` }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="font-semibold text-[var(--rose)] text-lg">
                  {t.pitta} (पित्त)
                </span>
                <span className="text-lg font-bold text-white/90">{Math.round(pcts.P)}%</span>
              </div>
              <div className="dosha-bar-bg">
                <div className="dosha-bar-fill dosha-bar-pitta" style={{ width: `${pcts.P}%` }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="font-semibold text-[var(--emerald)] text-lg">
                  {t.kapha} (कफ)
                </span>
                <span className="text-lg font-bold text-white/90">{Math.round(pcts.K)}%</span>
              </div>
              <div className="dosha-bar-bg">
                <div className="dosha-bar-fill dosha-bar-kapha" style={{ width: `${pcts.K}%` }} />
              </div>
            </div>
            <p className="text-sm text-white/50 text-center mt-4">
              ({totalAnswered} {lang === 'en' ? 'informative answers' : lang === 'hi' ? 'सूचनात्मक उत्तर' : 'माहितीपूर्ण उत्तरे'})
            </p>
          </div>

          {/* Description */}
          <div className="mb-8">
            <h4 className="heading-font text-xl font-semibold text-white/90 mb-3">
              {t.description}
            </h4>
            <p className="text-white/80 leading-relaxed text-lg">
              {result.description[lang]}
            </p>
          </div>

          {/* Tips */}
          <div className="mb-10">
            <h4 className="heading-font text-xl font-semibold text-white/90 mb-3">
              {t.dietTips}
            </h4>
            <div className="bg-[rgba(16,185,129,0.1)] border border-[rgba(16,185,129,0.3)] rounded-2xl p-6 backdrop-blur-sm">
              <p className="text-white/80 leading-relaxed whitespace-pre-line">
                {result.tips[lang]}
              </p>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="bg-[rgba(244,63,94,0.1)] border border-[rgba(244,63,94,0.3)] rounded-2xl p-5 mb-8 backdrop-blur-sm">
            <p className="text-sm text-[var(--rose)] leading-relaxed flex items-start gap-2">
              <span className="text-xl">⚕️</span>
              <span>{t.disclaimer}</span>
            </p>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center no-print">
            <button onClick={() => window.print()} className="btn-primary">
              🖨️ {t.download}
            </button>
            {stopped && canContinue && (
              <button onClick={handleContinue} className="btn-secondary">
                📝 {t.answerMore}
              </button>
            )}
            <button onClick={handleRetake} className="btn-secondary">
              🔄 {t.retake}
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
